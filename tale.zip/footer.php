</div><!-- /#content-holder -->
<div id="footer">
  <div class="container">
    <div class="mw-ui-row">
      <div class="mw-ui-col" id="copyright">
        <div class="edit" field="footer-left" rel="global">
          <p class="element">Copyright &copy; All rights reserved</p>
        </div>
      </div>
      
      <div class="mw-ui-col" id="powered">
        <div><a href="https://microweber.com/" title="Create free Website &amp; Online Shop">Create Website</a> with <a href="https://microweber.com" target="_blank" title="Microweber CMS">Microweber</a></div>
      </div>
    </div>
  </div>
</div>
</div>
<!-- /#main-container -->

</body>
</html>