<a href="javascript:;" onClick="mw.kuler.init();$('#mw_kuler').toggle();">.</a>

<script>
mw.kuler = {};

mw.kuler.init = function(search_kw){
	var url = '//api.microweber.com/service/kuler/';
	
	 
	if(typeof(search_kw) != 'undefined'){
		var url = '//api.microweber.com/service/kuler/?q='+search_kw;
	
	}
	$.getJSON( url, function( data ) {
	  var items = [];
	  $.each( data, function( key, val ) {
		  
		  var color_items = val.toString().split(',');
		  var color_items_preview = '<table><tr>';
		   for (var i=0;i<color_items.length;i++)
			{ 
			color_items_preview =color_items_preview+ "<td style='background-color:"+color_items[i]+"'>&nbsp;</td>" ;
			}
		color_items_preview =color_items_preview+ '</tr></table>' ;

		  
		items.push( "<li id='mw_kuler_" + key + "' onclick=\"mw.kuler.set('"+val+"')\">" + color_items_preview + "</li>" );
	  });
	 
	  var kuler_out = "<ul>"+items.join( "" )+"</ul>";
	   	  
	  
	  $("#mw_kuler").html(kuler_out)
	  //.appendTo( "#mw_kuler" )
	  
	});


	
}

mw.kuler.search = function(){
	var q = $('#kuler_color_search').val();
	 mw.kuler.init(q);
}
mw.kuler.set = function(colors){
		colors = colors.replace(/#/g,'');
	
		mw.$("#kuler_colors").val(colors).trigger("change");
		mw.$("#color-scheme-input").val('kuler').trigger("change");
		


        var csslink = window.parent.document.getElementById('colorscss');
        var url = mw.settings.template_url + 'css/colors/kuler.php?v='+mw.random()+'&colors='+colors;
        csslink.href = url;



}

</script>
<input type="search" onkeyup="mw.on.stopWriting(event, function(){mw.kuler.search()})" name="kuler_color_search" id="kuler_color_search" />
<div id="mw_kuler" style="display:none">
 

</div>