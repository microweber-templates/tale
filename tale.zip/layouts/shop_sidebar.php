
<div class="edit sidebar" field="shopsidebar" rel="inherit">
    <div class="box-container">
        <h4 class="element sidebar-title">Shop Categories</h4>
    	<div class="sidebar-box">
            <module type="categories" content-id="<?php print PAGE_ID; ?>" />
        </div>
    </div>
</div>


