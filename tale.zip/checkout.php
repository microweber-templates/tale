<?php include TEMPLATE_DIR. "header.php"; ?>
<div class="container checkout-page">
  <div class="box-container">
    <div  class="edit" field="checkout_page" rel="content"><h2>Complete your order</h2>
      <module type="shop/checkout" id="cart_checkout" />
    </div>
  </div>
</div>
<?php include TEMPLATE_DIR.  "footer.php"; ?>
