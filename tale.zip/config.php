<?php

$config = array();
$config['name'] = "Tale";
$config['author'] = "Microweber";
$config['version'] = 1.0;