<?php

/*

type: layout
content_type: static
name: Clean
position: 1
is_default: true
description: Clean layout

*/


?>
<?php include TEMPLATE_DIR. "header.php"; ?>

<section id="content"> 
  <div class="container edit" field="content" rel="content">
      <div class="box-container">
          <div class="mw-row">
            <div class="mw-col" style="width: 100%">
                <div class="mw-col-container">
                    <div class="mw-empty"></div>
                </div>
            </div>
          </div>
      </div>
  </div>
</section>


<?php include TEMPLATE_DIR. "footer.php"; ?>
